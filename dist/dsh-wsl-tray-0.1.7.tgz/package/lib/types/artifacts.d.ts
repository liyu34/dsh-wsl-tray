/**
 * Generated artifact templates: the WSL-side start script and the Windows-side
 * tray helper. Both are plain text so they can be written without any Windows
 * process, then a short PowerShell invocation creates the .lnk shortcut.
 *
 * The tray helper also carries the WATCHDOG, which answers the three design
 * questions of this feature:
 *   1. How DSH liveness is judged: an HTTP probe of the web URL on a timer;
 *      `downThreshold` consecutive failed probes declare DSH down (each probe
 *      records its status code / error text so "refused", "timeout" and
 *      "bad status" stay distinguishable in the log).
 *   2. Restart success is known by the URL answering again within
 *      `restartWaitSec`; each unanswered window counts one failed restart, and
 *      after `maxRestartFailures` consecutive failures the watchdog PAUSES
 *      instead of restarting forever (resume from the tray menu, or it
 *      auto-resumes as soon as DSH answers again).
 *   3. Everything (probes, transitions, restart attempts, pause/resume) is
 *      appended to watchdog.log with timestamps and levels, and a compact
 *      watchdog-status.json is rewritten each tick for the host card.
 */
export declare const PLUGIN_ID = "dsh-wsl-tray";
export declare const WSL_DIR_NAME = "dsh-wsl-tray";
export declare const WIN_DIR_REL = ".dsh/dsh-wsl-tray";
export declare const TRAY_SCRIPT_NAME = "dsh-tray.ps1";
export declare const TRAY_VBS_NAME = "dsh-tray.vbs";
export declare const ICON_FILE_NAME = "dsh.ico";
export declare const START_SCRIPT_NAME = "start.sh";
export declare const STOP_SCRIPT_NAME = "stop.sh";
export declare const WATCHDOG_LOG_NAME = "watchdog.log";
export declare const WATCHDOG_STATUS_NAME = "watchdog-status.json";
export declare const DEFAULT_SHORTCUT_NAME = "DeepSeek Harness";
export declare const DEFAULT_WEB_URL = "http://127.0.0.1:3080";
/** Parameters baked into both generated scripts. */
export interface LaunchConfig {
    /** WSL distro name passed to `wsl.exe -d`. */
    distro: string;
    /** DSH web URL the tray opens and the start script polls. */
    webUrl: string;
    /** Shortcut display name (without the .lnk suffix). */
    shortcutName: string;
    /** WSL-side path of the generated start script. */
    wslStartScript: string;
    /** WSL-side path of the generated stop script. */
    wslStopScript: string;
}
/**
 * Baked-in watchdog tuning. The tray helper is generated text, so changing
 * these values only takes effect after a regenerate (the plugin's `ensure`
 * compares content and rewrites the tray helper when it differs).
 */
export interface WatchdogConfig {
    /** Master switch. */
    enabled: boolean;
    /** Seconds between probes. */
    probeIntervalSec: number;
    /** HTTP probe timeout per attempt. */
    probeTimeoutSec: number;
    /** Consecutive failed probes that declare DSH down. */
    downThreshold: number;
    /** Max seconds a restart may take before it counts as failed. */
    restartWaitSec: number;
    /** Give up (pause) after this many consecutive failed restart attempts. */
    maxRestartFailures: number;
    /** Cooldown between two failed restart attempts. */
    restartBackoffSec: number;
}
export declare const DEFAULT_WATCHDOG_CONFIG: WatchdogConfig;
/**
 * Build the WSL-side launcher. It starts the same DSH web CLI the running
 * plugin host came from, waits for readiness, and opens the default browser.
 *
 * Source checkouts are launched through their BUILD OUTPUT only. Running one
 * from `src` (tsx) puts a src instance and a lib instance of the same packages
 * in one process — plugin packages resolve through the runtime mode, which
 * loads lib — and symbols never cross instances, so tool calls fail with
 * undefined state. When a project path is configured explicitly, a missing
 * build output is a hard error rather than a silent fallback to another
 * install the user did not ask for.
 *
 * @param params - launch facts resolved from the running host.
 */
export declare function buildStartScript(params: {
    nodeBin: string;
    sourceCli: string | null;
    sourceCwd: string | null;
    bakedCli: string | null;
    webUrl: string;
    /** True when the project path was set by the user (not auto-detected). */
    sourceConfigured?: boolean;
}): string;
/**
 * Build the WSL-side stop script. The tray runs it through `wsl.exe`; it
 * stops exactly the instance start.sh launched (PID file, written before
 * exec so it tracks the final DSH process), then falls back to a pkill whose
 * bracketed patterns cover every launcher flavor (source build output, npm
 * global, npx all end in `bin.js web`) without matching the wsl.exe/bash
 * wrapper that carries the pattern text in its own command line. A dev
 * instance started from source (`node --import tsx/esm .../src/bin.ts web`) is
 * covered by a second pattern, because "restart DSH" must also replace one.
 */
export declare function buildStopScript(): string;
/**
 * Build the Windows tray helper, including the watchdog state machine.
 *
 * Watchdog phases: `starting` (initial boot grace) → `probing` (steady state)
 * → `restarting` (after a restart trigger, waiting for DSH to answer) →
 * `backoff` (cooldown after a failed restart) or `paused` (auto-give-up after
 * `maxRestartFailures`, or user pause). Any phase returns to `probing` the
 * moment DSH answers again.
 * @param config - launch facts baked into the script.
 * @param watchdog - watchdog tuning baked into the script (defaults when omitted).
 */
export declare function buildTrayScript(config: LaunchConfig, watchdog?: WatchdogConfig): string;
/**
 * Build the Windows-side hidden launcher for the tray helper. The shortcut
 * points at wscript.exe (a GUI-subsystem host, no console) and passes this
 * script; the script derives the PowerShell path from its own location and
 * starts the tray helper with window style 0.
 */
export declare function buildTrayVbs(): string;
